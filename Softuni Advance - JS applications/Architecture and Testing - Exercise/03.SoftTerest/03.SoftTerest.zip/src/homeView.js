const home = document.getElementsByClassName('container')[1]
export function homeView(ctx, body) {
    body.appendChild(home)
    // ctx.check()
}