// const navigation = document.getElementsByTagName('nav')[0];
// const registerForm = document.getElementById('form-sign-up');
// const loginForm = document.getElementById('form-login');
// const contianer = document.getElementById('container');
// const movie = contianer.cloneNode('deep')

// navigation.addEventListener('click', navigate)
// function check() {
//     if (sessionStorage.getItem('accesstoken')) {
//         [...navigation.getElementsByClassName('nav-item guest')].forEach(el => el.style.display = 'none');
//         [...navigation.getElementsByClassName('nav-item user')].forEach(el => el.style.display = 'inline-block')
//     } else {
//         [...navigation.getElementsByClassName('nav-item user')].forEach(el => el.style.display = 'none');
//         [...navigation.getElementsByClassName('nav-item guest')].forEach(el => el.style.display = 'inline-block');
//     }
// }
// function navigate(e) {
//     e.preventDefault();
//     if (e.target.tagName === 'A') {
//         contianer.replaceChildren(navigation)
//         if (e.target.textContent === 'Register') {
            
//         } else if (e.target.textContent === 'Login') {
//             contianer.appendChild(loginForm)
//         } else if (e.target.textContent === 'Movies') {

//         }
//     }
// }
