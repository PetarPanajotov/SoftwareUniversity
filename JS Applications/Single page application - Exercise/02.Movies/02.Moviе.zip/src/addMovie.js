export function addMovieView() {

}